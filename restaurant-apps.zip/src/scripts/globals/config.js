const config = {
  base_url: 'https://restaurant-api.dicoding.dev',
};

export default config;
